<?php
/**
 * Template Name: Full Width
 * Full width template for Lighthouse theme
 *
 * Please browse readme.txt for credits and forking information
 * @package Lighthouse
 */

get_header(); ?>

		<div class="container">
            <div class="row">
				<div id="primary" class="">
					<main id="main" class="site-main" role="main">



					</main><!-- #main -->
				</div><!-- #primary -->

			</div> <!--.row-->
        </div><!--.container-->
        <?php get_footer(); ?>
